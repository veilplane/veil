# veilctl completion for fish: veilctl completion fish | source
complete -c veilctl -f -a '(veilctl __complete (commandline -opc)[2..-1] (commandline -ct) 2>/dev/null)'
